<?php

namespace Brick\PhoneNumber;

/**
 * Base class for phone number exceptions.
 */
class PhoneNumberException extends \Exception
{
}
