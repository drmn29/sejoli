<button type="button" name="button" class='button sejoli-check-autoresponder'><?php _e('Cek kode HTML', 'sejoli'); ?></button>
<div id='product-autoresponder-check' style='padding:20px 0;'></div>
