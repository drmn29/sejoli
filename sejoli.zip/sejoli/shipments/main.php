<?php

namespace SejoliSA;

class Shipment {

    /**
     * Construction
     */
    public function __construct() {

    }

}
