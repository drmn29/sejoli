Hi admin, ada order baru dari {{buyer-name}} dengan invoice {{invoice-id}}, produk {{product-name}} sebesar {{order-grand-total}}
