Halo {{buyer-name}}, pesanan anda untuk order {{order-id}} sebesar {{order-grand-total}} belum dibayarkan. Segera lakukan pembayaran sebelum invoicenya kami batalkan ya
