    <div class="footer-secure">
        <p>
            <span class="secure-tagline-img"><img src="<?php echo SEJOLISA_URL; ?>public/img/shield.png"> <?php _e('Informasi Pribadi Anda Aman', 'sejoli'); ?></span>
        </p>
    </div>
