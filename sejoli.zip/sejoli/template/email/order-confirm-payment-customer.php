<p><?php printf(__('Halo %s', 'sejoli'),'{{buyer-name}}' ); ?></p>
<p><?php _e('Terima kasih telah melakukan proses pembayaran, kami akan proses verifikasi pembayaran Anda. Semoga rezekinya {{buyer-name}} oleh Alloh diluaskan seluas lautan, usahanya diberikan keuntungan berlimpah, keluarganya diberikan kesehatan, dilancarkan segala urusannya, sisa umurnya diberikan keberkahan dan transaksi kita di ridhoi Alloh SWT. Aamiin...', 'sejoli'); ?></p>
<p><?php __('Berikut detail pembelian {{buyer-name}}', 'sejoli'); ?>
{{order-detail}}
{{order-meta}}
