<p><?php printf(__('Halo %s', 'sejoli'),'{{buyer-name}}' ); ?></p>
<p><?php _e('Pesananmu dengan detail sebagai berikut ', 'sejoli'); ?></p>
{{order-detail}}
{{order-meta}}
<p><?php _e('Telah kami lakukan batalkan ya, silahkan dicek kembali.', 'sejoli'); ?></p>
<p><?php _e('Terima kasih.', 'sejoli'); ?></p>
