<p><?php printf(__("Alhamdulillah, kamu baru saja mendapatkan komisi pesanan #%s dari %s. Informasi detailnya sebagai berikut</p>", "sejoli"), "{{invoice-id}}", "{{buyer-name}}"); ?></p>
{{order-detail}}
{{order-meta}}
<p><?php printf(__("Teman-teman bisa cek list komisi disini ya %s", "sejoli"), "{{memberurl}}"); ?></p>
