<p><?php printf(__('Alhamdulillah %s, komisi sebesar %s sudah kami cairkan ya.', 'sejoli'), '{{affiliate-name}}', '{{commission}}' ); ?></p>
<p><?php _e('Silahkan cek rekening banknya ya.', 'sejoli'); ?>
