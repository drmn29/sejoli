<p><?php printf(__('Halo %s', 'sejoli'),'{{buyer-name}}' ); ?></p>
<p><?php _e('Pesananmu telah selasi. Sebagai informasi, berikut detail pesananmu', 'sejoli'); ?></p>
{{order-detail}}
{{order-meta}}
