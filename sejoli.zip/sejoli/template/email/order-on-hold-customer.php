<p><?php printf(__('Halo %s', 'sejoli'),'{{buyer-name}}' ); ?></p>
<p><?php _e('Terima kasih untuk pesananmu. Saat ini kami sedang menunggu pembayaran darimu sebelum kami akan memprosesnya. Sebagai informasi, berikut detail pesananmu', 'sejoli'); ?></p>
{{order-detail}}
{{order-meta}}
