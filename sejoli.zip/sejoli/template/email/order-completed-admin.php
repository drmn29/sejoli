<p><?php printf(__('Pesanan order #%s dari %s telah selesai. Berikut detailnya', 'sejoli'), '{{invoice-id}}', '{{buyer-name}}' ); ?></p>
{{order-detail}}
{{order-meta}}
