<tr>
    <td>{{:rank}}</td>
    <td>{{:name}}</td>
    <td>{{:total}}</td>
</tr>