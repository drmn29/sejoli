<div class="ui segment">
    <div class="ui divided list">
        {{:content}}
    </div>
</div>