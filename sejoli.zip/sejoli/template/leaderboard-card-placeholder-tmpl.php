<div class="two wide column center aligned">
    <div class="ui fluid card">
        <a class="image" href="#">
            <div class="floating ui red circular label">?</div>
            <img src="http://via.placeholder.com/300x300">
        </a>
        <div class="content">
            <a class="header" href="#">?</a>
            <div class="meta">
                <a>? Sales</a>
            </div>
        </div>
    </div>
</div>