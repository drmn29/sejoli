Halo {{buyer-name}}

Berikut pesananmu ya

{{order-detail}}
{{order-meta}}

Harap segera lakukan pembayaran sebelum pukul {{close-time}} agar bisa kami proses ya
