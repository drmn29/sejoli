Nomor Invoice : *INV{{invoice-id}}*
Produk : *{{product-name}}*
Total Pembayaran : *{{order-grand-total}}*
