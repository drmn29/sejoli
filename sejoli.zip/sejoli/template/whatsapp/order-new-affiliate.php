Alhamdulillah {{affiliate-name}}, ada order baru dari {{buyer-name}}

{{order-detail}}
{{order-meta}}

Pantau terus ya, jika perlu follow-up terus {{buyer-name}} sampai deal ya.
