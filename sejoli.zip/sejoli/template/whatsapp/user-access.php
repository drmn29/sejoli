<?php _e('Nama User', 'sejoli'); ?> : *{{user-name}}*
<?php _e('Alamat Email', 'sejoli'); ?> : *{{user-email}}*
<?php _e('Nomor Telpon', 'sejoli'); ?> : *{{user-phone}}*
.
Login ke {{memberurl}}
