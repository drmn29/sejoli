<div class="header">{{:title}}</div>
<div class="content">{{:content}}</div>
